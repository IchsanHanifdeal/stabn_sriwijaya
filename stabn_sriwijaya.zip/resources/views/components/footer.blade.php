<footer class='p-5 border-t bg-dark'>
    <div class="text-center">
        <div class="container mx-auto flex justify-between items-center text-sm text-center">
            <span>&copy; {{ date('Y') }} STABN Sriwijaya™. All Rights Reserved.</span>
            <span>Made by Ichsan Hanifdeal</span>
        </div>
    </div>
</footer>